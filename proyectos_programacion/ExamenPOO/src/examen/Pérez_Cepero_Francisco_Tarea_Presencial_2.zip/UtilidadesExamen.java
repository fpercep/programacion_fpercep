package examen;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UtilidadesExamen {

	public static Date horaActual(Date now){
	SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
	Date hora = null ;
	return hora;
	}
	public static Calendar DiaSemana(Date now){
		Calendar diaSemana = null;
		return diaSemana;
	}
	public static Calendar DiasNavidad(Date now) {
		Calendar diasRestantes = null;
		return diasRestantes;
	
	}
	
	public static float ConsumoPorKilometro(float consumo) {
		float cosumoPorKm = consumo / 100;
		return cosumoPorKm;
	}
	
	public static float rangoEstimado(float consumo, float cantCombus) {
		float porKm = ConsumoPorKilometro(consumo);
		float rango = cantCombus / porKm;
		return rango;
	}
}