package examenTema4_2;

import java.util.Iterator;
import java.util.Scanner;

public class Isograma {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("Introduce una palabra: ");
		String texto = scan.nextLine();
		StringBuilder textoLimpio = limpiarTexto(texto);
		System.out.println(textoLimpio.toString());
		boolean esIsograma = esIsograma(textoLimpio);
		if (esIsograma) {
			System.out.println("Usted a escrito un Isograma");
		} else {
			System.out.println("Usted no a escrito un Isograma");
			mostrarLetrasRepetidas(textoLimpio);
		}
		scan.close();
	}

	private static StringBuilder limpiarTexto(String texto) {
		String abc = "qwertyuiopasdfghjklñzxcvbnm ";
		StringBuilder textoLimpio = new StringBuilder();
		texto = texto.toLowerCase();

		for (int i = 0; i < texto.length(); i++) {
			char letraP = texto.charAt(i);
			for (int j = 0; j < abc.length(); j++) {
				char letraABC = abc.charAt(j);
				if (letraP == letraABC) {
					textoLimpio.append(letraP);
				}
			}
		}
		return textoLimpio;
	}

	private static boolean esIsograma(StringBuilder textoSB) {
		boolean esIsograma = true;
		String letrasrepes = LetrasRepes(textoSB);
		if (letrasrepes.toString().length() > 0) {
			esIsograma = false;
		}
		return esIsograma;
	}

	private static void mostrarLetrasRepetidas(StringBuilder textoSB) {
		boolean esIsograma = esIsograma(textoSB);
		if (esIsograma) {
			System.out.println("No hay letras repetidas");
		} else {
			String letrasrepes = LetrasRepes(textoSB);
			System.out.println("Letras repetidas: "); 
			for (int i = 0; i < letrasrepes.length(); i++) {
				char letra = letrasrepes.charAt(i);
				System.out.print("   - " + letra + ": ");
			}
		}
	}

	private static String LetrasRepes(StringBuilder textoSB) {
		String abc = "qwertyuiopasdfghjklñzxcvbnm";
		StringBuilder letrasrepes = new StringBuilder();
		String texto = textoSB.toString();
		texto = texto.replace(" ", "");
		for (int i = 0; i < abc.length(); i++) {
			int contador = 0;
			char letraABC = abc.charAt(i);
			for (int j = 0; j < texto.length(); j++) {
				char letraP = texto.charAt(j);
				if (letraABC == letraP) {
					contador++;
				}
			}
			if (contador > 1) {
				for (int j = 0; j < contador; j++) {
					letrasrepes.append(letraABC);
				}
			}
		}
		return letrasrepes.toString();

	}

}
