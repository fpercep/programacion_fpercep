package granja;

public class CampoVacio extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9114004857393267795L;

	public CampoVacio() {
		// TODO Auto-generated constructor stub
	}

	public CampoVacio(String message) {
		super(message);
	}
}
