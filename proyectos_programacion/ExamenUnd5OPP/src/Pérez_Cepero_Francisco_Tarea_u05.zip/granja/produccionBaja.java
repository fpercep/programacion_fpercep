package granja;

public class produccionBaja extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5358708264294339563L;

	public produccionBaja() {
		// TODO Auto-generated constructor stub
	}

	public produccionBaja(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
