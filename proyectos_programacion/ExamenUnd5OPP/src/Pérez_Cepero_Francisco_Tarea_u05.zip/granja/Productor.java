package granja;

public interface Productor {
	public double calcularProduccion();
	public void mostarDatos();
}
