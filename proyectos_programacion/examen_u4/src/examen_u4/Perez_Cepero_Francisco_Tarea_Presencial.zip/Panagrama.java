package examen_u4;

import java.util.Scanner;

public class Panagrama {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String letras = "qwertyuiopasdfghjklñzxcvbnm";
		System.out.print("Introduzco la palabra: ");

		String palabra = scan.nextLine().toLowerCase();
		int cocidencia = letras.length();
		

		for (int i = 0; i < palabra.length() - 1; i++) {
			String letraPalabra = palabra.substring(i , i + 1);
			for (int j = 0; j < letras.length() - 1; j++) {
				String letraActual = letras.substring(j , j + 1);
				if (letraPalabra.equals(letraActual) ) {
					cocidencia --;}
			}
		}
		if (cocidencia == 0) {
			System.out.println("Su palabra es un pangrama");
		} else {
			System.out.println("Su palabra es un pangrama");
		}
		scan.close();
	}

}
